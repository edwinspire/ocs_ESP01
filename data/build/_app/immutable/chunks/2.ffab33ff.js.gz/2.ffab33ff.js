import{default as t}from"../entry/_page.svelte.3807b564.js";export{t as component};
