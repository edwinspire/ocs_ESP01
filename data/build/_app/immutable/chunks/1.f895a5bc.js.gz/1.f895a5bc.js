import{default as t}from"../entry/_error.svelte.5d0cabad.js";export{t as component};
