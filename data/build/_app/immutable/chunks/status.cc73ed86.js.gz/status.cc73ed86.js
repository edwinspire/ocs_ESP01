import{w as s}from"./index.22692e93.js";const a=s([]),o=s([]);export{o as a,a as s};
