import{default as t}from"../entry/_error.svelte.6cf4e5fa.js";export{t as component};
