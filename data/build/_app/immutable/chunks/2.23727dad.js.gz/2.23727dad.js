import{default as t}from"../entry/_page.svelte.7bcb49f6.js";export{t as component};
